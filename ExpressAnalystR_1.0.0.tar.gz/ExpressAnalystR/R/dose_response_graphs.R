GetFunctionalDetails <- function(data.sorted, gene.matches){
    data.sorted$Adjusted.Pvalue[data.sorted$Adjusted.Pvalue == 1] <- 0.99999
  return(list(
    pathways = data.sorted$name,
    pathways.bmd = data.sorted$bmd.med,
    pathways.pval = data.sorted$Pvalue,
    pathways.adjpval = data.sorted$Adjusted.Pvalue,
    pathways.nodesz = data.sorted$`Observed Hits`/data.sorted$`Gene Set Size`,
    pathways.observedhits = data.sorted$`Observed Hits`,
    gene.matches = gene.matches
  ))
}

PreparePODJSON <- function(fileNm, doseScale, xMin=-Inf, xMax=Inf, geneDB, org){
  #save.image("preparePod.RData");
  paramSet <- readSet(paramSet, "paramSet");
  dataSet <- readDataset(paramSet$dataName);

  bmdcalc.res <- FilterBMDResults(dataSet)
  
  if(doseScale == "log10"){
    bmdcalc.res[,3:6] <- log10(bmdcalc.res[,3:6])
  } else if(doseScale == "log2"){
    bmdcalc.res[,3:6] <- log2(bmdcalc.res[,3:6])
  }
  
  gene.vec <- as.matrix(bmdcalc.res[which(bmdcalc.res$bmd > xMin & bmdcalc.res$bmd < xMax),1])
  
  if (org == "noAnn") {
    # fill blank gene names with NA
    geneNms <- bmdcalc.res$id[order(bmdcalc.res$bmd)]
    geneNms[geneNms == ""] <- "---"

    res <- density(bmdcalc.res$bmd)

    pod <- list(
      geneIds = bmdcalc.res$id[order(bmdcalc.res$bmd)],
      geneNms = geneNms,
      geneBmds = sort(bmdcalc.res$bmd),
      x = res$x,
      y = res$y,
      Details = NULL
    )

  } else {
    # get gene set-based POD
    gs.POD <- gsPOD(dataSet$omicdata, bmdcalc.res, gene.vec, geneDB)


    #print(head(gs.POD$geneset.stats));
    #prepare pathways summary
    data.sorted = gs.POD$geneset.stats[order(gs.POD$geneset.stats$Adjusted.Pvalue),]
    details <- GetFunctionalDetails(data.sorted, gs.POD$geneset.matches)
    details$gene.matches <- lapply(details$gene.matches, function(gm) {
      if (is.null(gm)) {
        character(0)
      } else {
        gm <- as.character(gm)
        gm <- gm[!is.na(gm) & nzchar(gm)]
        unique(gm)
      }
    })

    details.out <- data.frame(
      Name = details$pathways,
      pathBMD = details$pathways.bmd,
      pval = details$pathways.pval,
      adj.pval = details$pathways.adjpval,
      perc.path = details$pathways.nodesz,
      num.hits = details$pathways.observedhits
    )
    data.table::fwrite(details.out, quote = FALSE, row.names = FALSE, sep = "\t", file="gse.txt");

    # write enrichment csv with gene symbols for each pathway
    csv.base <- gsub("\\.json$", "", fileNm)
    csv.nm <- paste0(csv.base, "_pathway_enrichment.csv")
    pathways <- details$pathways
    genes.by.path <- lapply(pathways, function(pw) {
      gm <- details$gene.matches[[pw]]
      if (is.null(gm)) {
        character(0)
      } else {
        gm <- as.character(gm)
        gm <- gm[!is.na(gm) & nzchar(gm)]
        unique(gm)
      }
    })
    symbols.by.path <- lapply(genes.by.path, function(ids) {
      if (length(ids) == 0) {
        character(0)
      } else {
        syms <- doEntrez2SymbolMapping(ids)
        syms[syms == ""] <- ids[syms == ""]
        syms
      }
    })
    enrich.csv <- data.frame(
      Pathway = pathways,
      BMD = details$pathways.bmd,
      Pvalue = details$pathways.pval,
      Adjusted.Pvalue = details$pathways.adjpval,
      PathwayFraction = details$pathways.nodesz,
      ObservedHits = details$pathways.observedhits,
      GeneIDs = vapply(genes.by.path, function(x) paste(unique(x), collapse = ";"), character(1)),
      GeneSymbols = vapply(symbols.by.path, function(x) paste(unique(x), collapse = ";"), character(1)),
      stringsAsFactors = FALSE
    )
    data.table::fwrite(enrich.csv, file = csv.nm)
    details$enrich_csv <- csv.nm

    resTable <- details.out;
    vis.type <- "curvefit";
    imgSet <- readSet(imgSet, "imgSet");
    rownames(resTable) <- NULL;
    imgSet$enrTables[[vis.type]] <- list()
    imgSet$enrTables[[vis.type]]$table <- resTable;
    imgSet$enrTables[[vis.type]]$library <- geneDB;
    imgSet$enrTables[[vis.type]]$algo <- "Overrepresentation Analysis"
    saveSet(imgSet, "imgSet");

    #prepare pathway table 
    details.50 <- details$gene.matches[names(details$gene.matches) %in% data.sorted$name]
    details.50 <- lapply(details.50, as.list)
    test <- reshape2::melt(details.50)[,c(1,3)]
    colnames(test) <- c("entrez", "pathway")
    test <- unique(test)
    test$symbol <- doEntrez2SymbolMapping(test$entrez)
    dataSet$pathway.ids <- test
    
    #generate dataframe with model fit interpolations
    fit.interp <- interpFits();
    qs::qsave(fit.interp, "fit.interp.qs");

    # fill blank gene names with NA
    geneNms <- doEntrez2SymbolMapping(bmdcalc.res$id)[order(bmdcalc.res$bmd)]
    geneNms[geneNms == ""] <- "---"

    res <- density(bmdcalc.res$bmd)


    pod <- list(
      geneIds = bmdcalc.res$id[order(bmdcalc.res$bmd)],
      geneNms = geneNms,
      geneBmds = sort(bmdcalc.res$bmd),
      x = res$x,
      y = res$y,
      Details = details
    )
  }
  
  # OPTIMIZED: Use jsonlite::write_json instead of RJSONIO + sink/cat
  jsonlite::write_json(pod, fileNm, auto_unbox = TRUE, pretty = FALSE);

  RegisterData(dataSet)
  return(1);
}

PlotGeneBMD <- function(gene.id, gene.symbol, scale){
  paramSet <- readSet(paramSet, "paramSet");
  dataSet <- readDataset(paramSet$dataName);
  params <- dataSet$drcfit.obj$fitres.filt[dataSet$drcfit.obj$fitres.filt$gene.id == gene.id,]
  model.nm <- as.vector(params$mod.name)
  b <- as.numeric(as.vector(params$b))
  c <- as.numeric(as.vector(params$c))
  d <- as.numeric(as.vector(params$d))
  if(is.nan(d)){
    d <- 1
  }
  e <- as.numeric(as.vector(params$e))
  if(is.nan(e)){
    e <- 1
  }

  bmd.params <- dataSet$bmdcalc.obj$bmdcalc.res[dataSet$bmdcalc.obj$bmdcalc.res$id == gene.id, ]
  bmd <- bmd.params$bmd
  bmdl <- bmd.params$bmdl
  bmdu <- bmd.params$bmdu
  
  exposure <- dataSet$drcfit.obj$dose
  
  if(scale != "natural"){
    exposure[exposure == 0] <- dataSet$zero.log
  }

  df <- data.frame(Exposure = exposure, Expression = dataSet$data.norm[gene.id,])
  p <- ggplot(data=df, aes(x=Exposure, y=Expression)) + geom_point() + xlab("Concentration") +
    ggtitle(gene.symbol) + theme_bw() + theme(plot.title = element_text(hjust = 0.5, face = "bold"))

  if(model.nm == "Poly2"){
    p <- p + geom_smooth(method = "lm", formula = y ~ poly(x, 2))
  }else if(model.nm == "Poly3"){
    p <- p + geom_smooth(method = "lm", formula = y ~ poly(x, 3))
  }else if(model.nm == "Poly4"){
    p <- p + geom_smooth(method = "lm", formula = y ~ poly(x, 4))
  }else if(model.nm == "Lin"){
    p <- p + geom_smooth(method = "lm", formula = y ~ x)
  }else if(model.nm == "Exp2"){
    .b <- b; .e <- e
    p <- p + stat_function(fun = function(x) .e * exp(.b * x), n = 1000)
  }else if(model.nm == "Exp3"){
    .b <- b; .d <- d; .e <- e
    p <- p + stat_function(fun = function(x) .e * exp(sign(.b) * (abs(.b) * x)^.d), n = 1000)
  }else if(model.nm == "Exp4"){
    .b <- b; .c <- c; .e <- e
    p <- p + stat_function(fun = function(x) .e * (.c - (.c - 1) * exp(-1 * .b * x)), n = 1000)
  }else if(model.nm == "Exp5"){
    .b <- b; .c <- c; .d <- d; .e <- e
    p <- p + stat_function(fun = function(x) .e * (.c - (.c - 1) * exp(-1 * (.b * x)^.d)), n = 1000)
  }else if(model.nm == "Hill"){
    .b <- b; .c <- c; .d <- d; .e <- e
    p <- p + stat_function(fun = function(x) .c + (.d - .c) / (1 + (x / .e)^.b), n = 1000)
  }else if(model.nm == "Power"){
    .b <- b; .c <- c; .e <- e
    p <- p + stat_function(fun = function(x) .e + .b * (x^.c), n = 1000)
  }

  p <- p + geom_rect(aes(xmin = bmdl, xmax = bmdu, ymin = -Inf, ymax = Inf), fill = "red3", alpha = 0.01) + 
    geom_vline(xintercept = bmdl, linetype = "dashed", color = "red3") + 
    geom_vline(xintercept = bmd, color = "red3") + 
    geom_vline(xintercept = bmdu, linetype = "dashed", color = "red3")

  if(scale == "log2"){
    if(model.nm == "Exp3" | model.nm == "Exp5" | model.nm == "Hill"){
      p <- p + scale_x_continuous(trans='pseudo_log')
    } else {
      p <- p + scale_x_continuous(trans='log2', breaks = unique(exposure), labels = labels)
    }
  } else if(scale == "log10"){
    if(model.nm == "Exp3" | model.nm == "Exp5" | model.nm == "Hill"){
      p <- p + scale_x_continuous(trans='pseudo_log')
    } else {
      p <- p + scale_x_continuous(trans='log10', breaks = unique(exposure), labels = labels)
    }
  }
  
  imgName <- paste("Gene_bmd_", gene.id, ".png", sep="");
  Cairo(file = imgName, width=280, height=320, type="png", bg="white");
  print(p)
  dev.off();

  imgSet <- readSet(imgSet, "imgSet");
  imgSet$PlotGeneBMD <- imgName;
    saveSet(imgSet, "imgSet");
}

PlotGeneDRCurve <- function(gene.id, gene.symbol, model.nm, b, c, d, e, bmdl, bmd, bmdu, scale){
  paramSet <- readSet(paramSet, "paramSet");
  dataSet <- readDataset(paramSet$dataName);
  require(ggplot2)
  require(scales)

  exposure <- dataSet$drcfit.obj$dose
  labels <- unique(exposure)

  if(scale != "natural"){
    exposure[exposure == 0] <- dataSet$zero.log
  }

  df <- data.frame(Dose = exposure, Expression = dataSet$data.norm[gene.id,])

  # Look up SDres for this gene to draw CI ribbon on nonlinear models
  fit.row <- dataSet$drcfit.obj$fitres.filt[dataSet$drcfit.obj$fitres.filt$gene.id == gene.id, ]
  SDres <- if(nrow(fit.row) > 0) as.numeric(fit.row$SDres[1]) else NA

  p <- ggplot(data=df, aes(x=Dose, y=Expression)) + geom_point() + ggtitle(gene.symbol) +
       theme_bw() +
       theme(plot.title = element_text(hjust = 0.5, face = "bold"),
             axis.text.x = element_text(angle=90)) +
       xlab("Concentration") +
       geom_rect(aes(xmin = bmdl, xmax = bmdu, ymin = -Inf, ymax = Inf), fill = "red3", alpha = 0.01) +
       geom_vline(xintercept = bmdl, linetype = "dashed", color = "red3") +
       geom_vline(xintercept = bmd, color = "red3") + geom_vline(xintercept = bmdu, linetype = "dashed", color = "red3")

  # Helper: add curve + CI ribbon for nonlinear models using a dense x grid
  add_nl_curve <- function(p, fun, xseq, SDres) {
    y    <- sapply(xseq, fun)
    cdf  <- data.frame(Dose = xseq, fit = y)
    if (!is.na(SDres) && is.finite(SDres)) {
      cdf$lo <- y - 1.96 * SDres
      cdf$hi <- y + 1.96 * SDres
      p <- p + geom_ribbon(data = cdf, aes(x = Dose, ymin = lo, ymax = hi),
                           inherit.aes = FALSE, fill = "steelblue", alpha = 0.2)
    }
    p <- p + geom_line(data = cdf, aes(x = Dose, y = fit), inherit.aes = FALSE)
    return(p)
  }

  xseq <- seq(min(exposure), max(exposure), length.out = 500)

  if(model.nm == "Poly2"){
    p <- p + geom_smooth(method = "lm", formula = y ~ poly(x, 2))
  }else if(model.nm == "Poly3"){
    p <- p + geom_smooth(method = "lm", formula = y ~ poly(x, 3))
  }else if(model.nm == "Poly4"){
    p <- p + geom_smooth(method = "lm", formula = y ~ poly(x, 4))
  }else if(model.nm == "Lin"){
    p <- p + geom_smooth(method = "lm", formula = y ~ x)
  }else if(model.nm == "Exp2"){
    .b <- b; .e <- e
    p <- add_nl_curve(p, function(x) .e * exp(.b * x), xseq, SDres)
  }else if(model.nm == "Exp3"){
    .b <- b; .d <- d; .e <- e
    p <- add_nl_curve(p, function(x) .e * exp(sign(.b) * (abs(.b) * x)^.d), xseq, SDres)
  }else if(model.nm == "Exp4"){
    .b <- b; .c <- c; .e <- e
    p <- add_nl_curve(p, function(x) .e * (.c - (.c - 1) * exp(-1 * .b * x)), xseq, SDres)
  }else if(model.nm == "Exp5"){
    .b <- b; .c <- c; .d <- d; .e <- e
    p <- add_nl_curve(p, function(x) .e * (.c - (.c - 1) * exp(-1 * (.b * x)^.d)), xseq, SDres)
  }else if(model.nm == "Hill"){
    .b <- b; .c <- c; .d <- d; .e <- e
    p <- add_nl_curve(p, function(x) .c + (.d - .c) / (1 + (x / .e)^.b), xseq, SDres)
  }else if(model.nm == "Power"){
    .b <- b; .c <- c; .e <- e
    p <- add_nl_curve(p, function(x) .e + .b * (x^.c), xseq, SDres)
  }

  ## ── x-axis scaling ─────────────────────────────────────────────────────────
if (scale == "log2") {

  if (model.nm %in% c("Exp3", "Exp5")) {

    p <- p + scale_x_continuous(trans = scales::pseudo_log_trans(base = 2))

  } else {

    ## powers of 2 between the smallest >0 dose and the max dose
    rng     <- range(exposure[exposure > 0], na.rm = TRUE)
    breaks  <- 2^seq(floor(log2(rng[1])), ceiling(log2(rng[2])), by = 1)
    breaks  <- c(dataSet$zero.log, breaks)
    labelMap <- c("0", format(breaks[-1], scientific = FALSE))

    p <- p + scale_x_continuous(trans = "log2",
                                breaks = breaks,
                                labels = labelMap)
  }

} else if (scale == "log10") {

  if (model.nm %in% c("Exp3", "Exp5")) {

    p <- p + scale_x_continuous(trans = scales::pseudo_log_trans(base = 10))

  } else {

    ## powers of 10 between the smallest >0 dose and the max dose
    rng     <- range(exposure[exposure > 0], na.rm = TRUE)
    breaks  <- 10^seq(floor(log10(rng[1])), ceiling(log10(rng[2])), by = 1)
    breaks  <- c(dataSet$zero.log, breaks)
    labelMap <- c("0", format(breaks[-1], scientific = FALSE))

    p <- p + scale_x_continuous(trans = "log10",
                                breaks = breaks,
                                labels = labelMap)
  }
}

  
  imgName <- paste("Gene_", gene.symbol, "_", model.nm, "_", scale,".png", sep="");
  Cairo(file = imgName, width=280, height=320, type="png", bg="white");
  print(p)
  dev.off();

  imgSet <- readSet(imgSet, "imgSet");
  imgSet$PlotGeneDRCurve <- imgName;
    saveSet(imgSet, "imgSet");
}

PlotDRModelBars <- function(imgNm, dpi, format){
  paramSet <- readSet(paramSet, "paramSet")
  dataSet  <- readDataset(paramSet$dataName)

  require(ggplot2)

  df <- dataSet$bmdcalc.obj$bmdcalc.res
  df$all.pass <- as.logical(df$all.pass)          # ensure TRUE / FALSE

  # dynamic palette: only keep colours for levels that are present
  lvls      <- sort(unique(df$all.pass))          # e.g. c(TRUE) or c(FALSE, TRUE)
  colours   <- c("FALSE" = "#282726", "TRUE" = "#6A8A82")[as.character(lvls)]
  lbls      <- c("FALSE" = "No",     "TRUE" = "Yes")[as.character(lvls)]

  p <- ggplot(df, aes(x = mod.name, fill = all.pass)) +
       geom_bar(position = "stack") +
       scale_fill_manual(values = colours, labels = lbls, name = "BMD convergence?") +
       theme_bw() +
       xlab("Best fit model") +
       ylab("Count") +
       theme(axis.text.x = element_text(face = "bold"),
             legend.position = "bottom")

  imgNm <- sprintf("%sdpi%s.%s", imgNm, dpi, format)
  Cairo(file = imgNm, width = 8, height = 6, unit = "in", dpi = dpi,
        type = format, bg = "white")
  print(p)
  dev.off()

  imgSet <- readSet(imgSet, "imgSet")
  imgSet$PlotDRModelBars <- imgNm
    saveSet(imgSet, "imgSet");
}

PlotDRFilterSummary <- function(imgNm, dpi = 72, format = "png") {

  ## 1 ── Load data -----------------------------------------------------------
  paramSet <- readSet(paramSet, "paramSet")
  dataSet  <- readDataset(paramSet$dataName)

  require(ggplot2)
  require(Cairo)

  ## 2 ── Build counts --------------------------------------------------------
  dres   <- dataSet$bmdcalc.obj$bmdcalc.res
  fitres <- dataSet$bmdcalc.obj$fitres.bmd

  n_total   <- length(dataSet$itemselect$item)      # “Initial” = sig. features
  n_fitted  <- nrow(dres)                           # “Fitted”  = BMD-modelled

  mask_conv   <- dres$conv.pass
  mask_ci1    <- mask_conv & dres$CI.pass
  mask_ci2    <- mask_ci1  & dres$CI.pass2
  mask_low    <- mask_ci2  & dres$ld.pass
  mask_high   <- mask_low  & dres$hd.pass

  lof_thr <- 0.05
  fit_ok  <- rep(FALSE, n_fitted)
  hit     <- match(dres$id, fitres$gene.id, nomatch = 0)
  fit_ok[hit > 0] <- fitres$lof.p[hit] >= lof_thr
  mask_fitp <- mask_high & fit_ok

  counts <- c(
    Initial      = n_total,
    Fitted       = n_fitted,
    `BMD/BMDL`   = sum(mask_conv),
    `BMDU/BMDL`  = sum(mask_ci1),
    `BMDU/BMD`   = sum(mask_ci2),
    Lowdose      = sum(mask_low),
    Highdose     = sum(mask_high),
    FitP         = sum(mask_fitp),
    All          = sum(mask_fitp)
  )

  pct <- round(counts / n_total * 100)

  df <- data.frame(
    step    = factor(names(counts), levels = rev(names(counts))), # reverse for ggplot
    count   = counts,
    percent = pct
  )

  ## 3 ── Build the bar plot --------------------------------------------------
  p <- ggplot(df, aes(x = step, y = count, fill = percent)) +
    geom_col(width = 0.7, colour = "black") +
    geom_text(aes(label = paste0(count, " (", percent, "%)")),
              hjust = 1.05, colour = "white", size = 5.0) +     # was 3.8
    scale_fill_gradient(low = "#6AA2AD", high = "#C5D97B") +
    coord_flip(clip = "off") +
    labs(x = NULL, y = "Features Remaining") +
    theme_minimal(base_size = 14) +                              # was 11
    theme(
      legend.position = "none",
      plot.margin = margin(10, 40, 10, 120),   # extra left margin for long labels
      axis.text.y = element_text(face = "bold", size = 13),      # +3 pt
      axis.text.x = element_text(size = 12)                      # clearer axis
    )

  ## 4 ── Save & register -----------------------------------------------------
  outFile <- paste0(imgNm, "dpi", dpi, ".", format)
  if (dpi == 72) dpi <- 96
  Cairo(file = outFile, width = 8, height = 6, unit = "in",
        dpi = dpi, type = format, bg = "white")
  print(p)
  dev.off()

  imgSet <- readSet(imgSet, "imgSet")
  imgSet$PlotDRFilterSummary <- outFile
    saveSet(imgSet, "imgSet");
}

PlotDRHistogram <- function(imgNm,
                            dpi,
                            format,
                            units,
                            scale,
                            width = NA) {

  paramSet <- readSet(paramSet, "paramSet")
  dataSet  <- readDataset(paramSet$dataName)

  require(ggplot2)
  require(Cairo)

  ## existing PODs
  s.pods <- sensPOD(pod = c("feat.20", "feat.10th", "mode"), scale)

  ## BMD values (raw) for LCRD & histogram source
  bmd.hist <- subset(dataSet$bmdcalc.obj$bmdcalc.res, all.pass)
  bmd.vals <- bmd.hist$bmd

  ## ---- LCRD on RAW scale, then convert to plot scale -----------------------
  lcrd_val <- NA_real_
  # pick an ID column to pair with BMDs (fallbacks are fine)
  probe <- if ("gene.id" %in% names(bmd.hist)) as.character(bmd.hist$gene.id) else
           if ("probe"   %in% names(bmd.hist)) as.character(bmd.hist$probe)   else
           if ("item"    %in% names(bmd.hist)) as.character(bmd.hist$item)    else
           seq_len(nrow(bmd.hist))

  ok <- is.finite(bmd.vals) & bmd.vals > 0 & !is.na(probe)
  if (sum(ok) >= 1) {
    lcrd_raw <- LCRD(bmc = bmd.vals[ok], probe = probe[ok])$LCRD_Result$BMC
    lcrd_val <- switch(
      scale,
      log10 = log10(lcrd_raw),
      log2  = log2(lcrd_raw),
      lcrd_raw
    )
  }

  ## ---- apply plot scale to BMDs and (if needed) to s.pods ------------------
  if (scale == "log10") {
    bmd.vals <- log10(bmd.vals)
    # uncomment the next line ONLY if sensPOD() returns RAW values
    # s.pods   <- log10(s.pods)
    xTitle   <- "log10(Feature-level BMD)"
  } else if (scale == "log2") {
    bmd.vals <- log2(bmd.vals)
    # s.pods   <- log2(s.pods)
    xTitle   <- "log2(Feature-level BMD)"
  } else {
    xTitle <- "Feature-level BMD"
  }

  bmd.df <- data.frame(bmd = bmd.vals)

  ## ---- Colours, legend text, ordering --------------------------------------
  pod.cols <- c(
    gene20         = "#D62728",  # 20th feature
    mode           = "#FF7F0E",  # max 1st peak
    percentile10th = "#2CA02C",  # 10th percentile
    lcrd           = "#1F77B4"   # LCRD
  )
  breaks <- c("gene20", "mode", "percentile10th", "lcrd")

  legend.labels <- c(
    paste0("20th feature: ",    ifelse(is.finite(s.pods["feat.20"]),   signif(s.pods["feat.20"], 2), "NA")),
    paste0("Max 1st peak: ",    ifelse(is.finite(s.pods["mode"]),      signif(s.pods["mode"],     2), "NA")),
    paste0("10th percentile: ", ifelse(is.finite(s.pods["feat.10th"]), signif(s.pods["feat.10th"],2), "NA")),
    paste0("LCRD: ",            ifelse(is.finite(lcrd_val),            signif(lcrd_val,           2), "NA"))
  )

  ## ---- Plot -----------------------------------------------------------------
  p <- ggplot(bmd.df, aes(x = bmd)) +
    geom_histogram(aes(y = after_stat(count)),
                   bins   = 30,
                   fill   = "lightblue",
                   colour = "black",
                   alpha  = 0.85) +
    { if (is.finite(s.pods["feat.20"]))
        geom_vline(aes(xintercept = s.pods["feat.20"], colour = "gene20"), size = 1) } +
    { if (is.finite(s.pods["mode"]))
        geom_vline(aes(xintercept = s.pods["mode"], colour = "mode"), size = 1) } +
    { if (is.finite(s.pods["feat.10th"]))
        geom_vline(aes(xintercept = s.pods["feat.10th"], colour = "percentile10th"), size = 1) } +
    { if (is.finite(lcrd_val))
        geom_vline(aes(xintercept = lcrd_val, colour = "lcrd"), size = 1) } +
    scale_color_manual(
      name   = "tPOD",
      breaks = breaks,
      values = pod.cols,
      labels = legend.labels
    ) +
    scale_y_continuous(expand = expansion(mult = c(0, 0.14))) +
    theme_bw(base_size = 11 * 1.3) +
    xlab(xTitle) +
    ylab("Count") +
    theme(
      axis.text.x       = element_text(face = "bold"),
      legend.position   = "right",
      legend.direction  = "vertical",
      legend.box.margin = margin(t = 6, l = 8),
      plot.margin       = margin(t = 10, r = 8, b = 5, l = 8),
      legend.title      = element_text(size = rel(1)),
      legend.text       = element_text(size = rel(0.9))
    )

  ## ---- Output ----------------------------------------------------------------
  if (is.na(width) || width <= 0) {
    w <- 10; h <- 7
  } else {
    w <- width; h <- width * 0.75
  }
  imgFile <- paste0(imgNm, "dpi", dpi, ".", format)

  Cairo(file   = imgFile,
        width  = w,
        height = h,
        unit   = "in",
        dpi    = dpi,
        type   = format,
        bg     = "white")
  print(p)
  dev.off()

  imgSet <- readSet(imgSet, "imgSet")
  imgSet$PlotDRHistogram <- imgFile
    saveSet(imgSet, "imgSet");
}


PlotPWHeatmap <- function(pathway, pwcount, units){
  paramSet <- readSet(paramSet, "paramSet");
  dataSet <- readDataset(paramSet$dataName);

    require(pheatmap)
    require(grid)

    pws <- dataSet$pathway.ids
    fit.interp <- qs::qread("fit.interp.qs");
    bmd.vals <- dataSet$html.resTable[,c(1,5)]

    pw.genes <- pws[pws$pathway == pathway,][,c(1,3)]

    pw.data <- base::merge(pw.genes, fit.interp, by.x = "entrez", by.y = "row.names", all = FALSE)
    pw.data <- base::merge(bmd.vals, pw.data, by.x = "gene.id", by.y = "entrez", all = FALSE)
    pw.data <- distinct(pw.data)
    rownames(pw.data) <- pw.data$symbol
    sym.bmd <- pw.data[,c(2:3)]
    pw.data <- pw.data[,-c(1:3)]

    # reduce the number of significant digits
    labels.col <- as.numeric(colnames(pw.data))
    labels.col <- signif(labels.col, 2)

    # make labels to display on heatmap
    inds <- c(seq(1,100,by=20),100)
    labs.col <- rep("", 100)
    labs.col[inds] <- labels.col[inds]

    # find the index of each bmd
    bmd.ind <- unlist(lapply(sym.bmd[,1], function(x){min(which(labels.col > x))}))
    names(bmd.ind) <- sym.bmd$symbol

    # convert down regulated - version 2
    down.reg <- pw.data[,1] > 0.25
    names(down.reg) <- rownames(pw.data)
    pw.data[down.reg,] <- -1*(pw.data[down.reg,] - 1)

    # re-order data (BMD)
    pw.data <- pw.data[order(bmd.ind),]
    down.reg <- down.reg[order(bmd.ind)]
    bmd.ind <- bmd.ind[order(bmd.ind)]

    # change color of bmd cells
    for(i in c(1:dim(pw.data)[1])){
      pw.data[i, bmd.ind[i]] <- 1.01
    }

    # Change names of factors
    down.reg[down.reg==TRUE] <- "Down"
    down.reg[down.reg==FALSE] <- "Up"
    ann.row <- data.frame(Regulation = as.factor(down.reg))

    # Specify colors
    ann.cols <- list(Regulation = c(Up = "#821717", Down = "#4c743e"))[1]
    cell.cols <- c(colorRampPalette(c("#5c998a", "#e6a519", "#b2343e"))(100), "#000000")

    # get x-axis label
    xlab <- paste0("Concentration (", units, ")")

    # print out image
    imgNm <- paste("Pw_", pwcount, ".png", sep="");
    Cairo (file=imgNm, width=8, height=8, unit="in",dpi=300, type="png", bg="white");
    setHook("grid.newpage", function() pushViewport(viewport(x=1,y=0.95,width=1, height=0.9, name="vp", just=c("right","top"))), action="prepend")
    pheatmap(pw.data, cluster_cols = FALSE, cluster_rows = FALSE, show_rownames = TRUE, show_colnames = TRUE, 
             border_color = NA, labels_col = labs.col, annotation_row = ann.row, legend = FALSE,
             color = cell.cols, annotation_colors = ann.cols, annotation_names_row = FALSE)
    setHook("grid.newpage", NULL, "replace")
    grid.text(xlab, y=-0.02, x = 0.4, gp=gpar(fontsize=12))
    grid.text(pathway, y = 1.02, x = 0.5, gp=gpar(fontsize=14, fontface="bold"))
    dev.off();

    imgSet <- readSet(imgSet, "imgSet");
    imgSet$PlotPWHeatmap <- imgNm;
    saveSet(imgSet, "imgSet");
}

###################
###################

PlotDRAccumulationAll <- function(imgNm, dpi, format, units, scale) {
  paramSet <- readSet(paramSet, "paramSet")
  dataSet  <- readDataset(paramSet$dataName)

  require(ggplot2)
  require(Cairo)

  ## Get all BMDs that passed filters
  bmd.data <- subset(dataSet$bmdcalc.obj$bmdcalc.res, all.pass)

  if (nrow(bmd.data) == 0) {
    return(0)
  }

  ## Sort BMDs in ascending order (keep raw for calculations)
  bmd.vals.raw <- sort(bmd.data$bmd)

  ## tPOD values (feat.20, feat.10th, mode) on requested scale
  s.pods <- sensPOD(pod = c("feat.20", "feat.10th", "mode"), scale)

  ## LCRD on RAW scale, then convert to plot scale
  lcrd_val <- NA_real_
  probe <- if ("gene.id" %in% names(bmd.data)) as.character(bmd.data$gene.id) else
           if ("probe"   %in% names(bmd.data)) as.character(bmd.data$probe)   else
           if ("item"    %in% names(bmd.data)) as.character(bmd.data$item)    else
           seq_len(nrow(bmd.data))
  ok <- is.finite(bmd.data$bmd) & bmd.data$bmd > 0 & !is.na(probe)
  if (sum(ok) >= 1) {
    lcrd_raw <- LCRD(bmc = bmd.data$bmd[ok], probe = probe[ok])$LCRD_Result$BMC
    lcrd_val <- switch(
      scale,
      log10 = log10(lcrd_raw),
      log2  = log2(lcrd_raw),
      lcrd_raw
    )
  }

  ## Apply scale transformation if needed
  bmd.vals <- bmd.vals.raw
  if (scale == "log10") {
    bmd.vals <- log10(bmd.vals)
    xTitle <- paste0("log10(Feature-level BMD) (", units, ")")
  } else if (scale == "log2") {
    bmd.vals <- log2(bmd.vals)
    xTitle <- paste0("log2(Feature-level BMD) (", units, ")")
  } else {
    xTitle <- paste0("Feature-level BMD (", units, ")")
  }

  ## tPOD legend info
  pod.cols <- c(
    gene20         = "#D62728",
    mode           = "#FF7F0E",
    percentile10th = "#2CA02C",
    lcrd           = "#1F77B4"
  )
  pod.breaks <- c("gene20", "mode", "percentile10th", "lcrd")
  pod.labels <- c(
    paste0("20th feature: ",    ifelse(is.finite(s.pods["feat.20"]),   signif(s.pods["feat.20"], 2), "NA")),
    paste0("Max 1st peak: ",    ifelse(is.finite(s.pods["mode"]),      signif(s.pods["mode"],     2), "NA")),
    paste0("10th percentile: ", ifelse(is.finite(s.pods["feat.10th"]), signif(s.pods["feat.10th"],2), "NA")),
    paste0("LCRD: ",            ifelse(is.finite(lcrd_val),            signif(lcrd_val,           2), "NA"))
  )

  ## Calculate cumulative count (actual number of genes)
  n_genes <- length(bmd.vals)
  cumulative_count <- seq_len(n_genes)

  ## Create data frame for plotting
  accum.df <- data.frame(
    bmd = bmd.vals,
    cumulative = cumulative_count
  )

  ## Create the accumulation plot without markers
  p <- ggplot(accum.df, aes(x = bmd, y = cumulative)) +
    geom_line(color = "#2CA02C", size = 1.2) +
    { if (is.finite(s.pods["feat.20"]))
        geom_vline(aes(xintercept = s.pods["feat.20"], colour = "gene20"), size = 1) } +
    { if (is.finite(s.pods["mode"]))
        geom_vline(aes(xintercept = s.pods["mode"], colour = "mode"), size = 1) } +
    { if (is.finite(s.pods["feat.10th"]))
        geom_vline(aes(xintercept = s.pods["feat.10th"], colour = "percentile10th"), size = 1) } +
    { if (is.finite(lcrd_val))
        geom_vline(aes(xintercept = lcrd_val, colour = "lcrd"), size = 1) } +
    scale_color_manual(
      name   = "tPOD",
      breaks = pod.breaks,
      values = pod.cols,
      labels = pod.labels
    ) +
    scale_y_continuous(
      limits = c(0, n_genes),
      expand = expansion(mult = c(0.01, 0.05))
    ) +
    scale_x_continuous(expand = expansion(mult = c(0.02, 0.02))) +
    theme_bw(base_size = 11 * 1.3) +
    xlab(xTitle) +
    ylab("Cumulative Number of Genes") +
    ggtitle(paste0("Gene Accumulation Plot - All Genes (n=", n_genes, ")")) +
    theme(
      axis.text.x = element_text(face = "bold"),
      axis.text.y = element_text(face = "bold"),
      plot.title = element_text(hjust = 0.5, face = "bold", size = rel(1.1)),
      plot.margin = margin(t = 10, r = 10, b = 10, l = 10)
    )

  ## Save the plot
  imgFile <- paste0(imgNm, "dpi", dpi, ".", format)

  Cairo(
    file   = imgFile,
    width  = 10,
    height = 6,
    unit   = "in",
    dpi    = dpi,
    type   = format,
    bg     = "white"
  )
  print(p)
  dev.off()

  imgSet <- readSet(imgSet, "imgSet")
  imgSet$PlotDRAccumulationAll <- imgFile
  saveSet(imgSet, "imgSet")

  return(1)
}

PlotDRAccumulationTop100 <- function(imgNm, dpi, format, units, scale) {
  paramSet <- readSet(paramSet, "paramSet")
  dataSet  <- readDataset(paramSet$dataName)

  require(ggplot2)
  require(Cairo)

  ## Get all BMDs that passed filters
  bmd.data <- subset(dataSet$bmdcalc.obj$bmdcalc.res, all.pass)

  if (nrow(bmd.data) == 0) {
    return(0)
  }

  ## Sort BMDs in ascending order (keep raw values)
  bmd.vals.raw <- sort(bmd.data$bmd)

  ## Limit to top 100 genes with lowest BMDs
  n_genes_total <- length(bmd.vals.raw)
  n_genes <- min(100, n_genes_total)
  bmd.vals.raw <- bmd.vals.raw[1:n_genes]

  ## Apply scale transformation if needed
  bmd.vals <- bmd.vals.raw
  if (scale == "log10") {
    bmd.vals <- log10(bmd.vals)
    xTitle <- paste0("log10(Feature-level BMD) (", units, ")")
  } else if (scale == "log2") {
    bmd.vals <- log2(bmd.vals)
    xTitle <- paste0("log2(Feature-level BMD) (", units, ")")
  } else {
    xTitle <- paste0("Feature-level BMD (", units, ")")
  }

  ## Calculate cumulative count (actual number of genes)
  cumulative_count <- seq_len(n_genes)

  ## Create data frame for plotting
  accum.df <- data.frame(
    bmd = bmd.vals,
    cumulative = cumulative_count
  )

  ## Calculate 20th gene marker position
  gene_20_idx <- min(20, n_genes)
  gene_20_bmd <- bmd.vals[gene_20_idx]
  gene_20_count <- gene_20_idx

  ## Create the accumulation plot with 20th gene marker
  label_offset <- max(1, n_genes * 0.08)
  p <- ggplot(accum.df, aes(x = bmd, y = cumulative)) +
    geom_line(color = "#2CA02C", size = 1.2) +
    ## 20th gene marker - horizontal dashed line only
    geom_hline(yintercept = gene_20_count, linetype = "dashed", color = "#FF7F0E", size = 0.8) +
    geom_point(aes(x = gene_20_bmd, y = gene_20_count), color = "#FF7F0E", size = 3.5, shape = 19) +
    annotate("text", x = gene_20_bmd, y = gene_20_count + label_offset,
             label = paste0("20th gene (", signif(bmd.vals.raw[gene_20_idx], 3), " ", units, ")"),
             color = "#FF7F0E", fontface = "bold", size = 4) +
    scale_y_continuous(
      limits = c(0, n_genes),
      breaks = scales::pretty_breaks(n = 5),
      expand = expansion(mult = c(0.01, 0.05))
    ) +
    scale_x_continuous(expand = expansion(mult = c(0.05, 0.05))) +
    theme_bw(base_size = 11 * 1.3) +
    xlab(xTitle) +
    ylab("Cumulative Number of Genes") +
    ggtitle(paste0("Gene Accumulation Plot - Top 100 Genes")) +
    theme(
      axis.text.x = element_text(face = "bold"),
      axis.text.y = element_text(face = "bold"),
      plot.title = element_text(hjust = 0.5, face = "bold", size = rel(1.1)),
      plot.margin = margin(t = 10, r = 10, b = 10, l = 10)
    )

  ## Save the plot
  imgFile <- paste0(imgNm, "dpi", dpi, ".", format)

  Cairo(
    file   = imgFile,
    width  = 8,
    height = 6,
    unit   = "in",
    dpi    = dpi,
    type   = format,
    bg     = "white"
  )
  print(p)
  dev.off()

  imgSet <- readSet(imgSet, "imgSet")
  imgSet$PlotDRAccumulationTop100 <- imgFile
  saveSet(imgSet, "imgSet")

  return(1)
}

## ---- Multi-dataset gene accumulation utilities -----------------------------
AccuReadBmdFile <- function(file) {
  if (!file.exists(file)) {
    return(NULL)
  }
  sep <- ifelse(grepl("\\\\.csv$", file, ignore.case = TRUE), ",", "\t")
  df <- tryCatch(
    read.table(file, header = TRUE, sep = sep, quote = "", comment.char = "", stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(df) || !("bmd" %in% names(df))) {
    return(NULL)
  }
  if ("all.pass" %in% names(df)) {
    ap <- df$all.pass
    if (!is.logical(ap)) {
      ap <- tolower(as.character(ap)) %in% c("true", "t", "1", "yes")
    }
    df <- df[ap, , drop = FALSE]
  }
  df
}

AccuExtractBmd <- function(df) {
  bmds <- suppressWarnings(as.numeric(df$bmd))
  bmds <- bmds[is.finite(bmds) & !is.na(bmds) & bmds > 0]
  bmds
}

AccuComputeTPods <- function(bmds_raw, probe, scale) {
  pod <- c("feat.20", "feat.10th", "mode", "lcrd")
  trans.pod <- rep(NA_real_, length(pod))
  names(trans.pod) <- pod

  bmds <- switch(
    scale,
    log10 = log10(bmds_raw),
    log2  = log2(bmds_raw),
    bmds_raw
  )

  if (length(bmds) == 0) {
    return(trans.pod)
  }

  if (length(bmds) >= 20) {
    bmd.sort <- sort(bmds)
    trans.pod["feat.20"] <- bmd.sort[20]
  }
  trans.pod["feat.10th"] <- unname(quantile(bmds, 0.1, na.rm = TRUE))

  if (length(bmds) > 1) {
    density.bmd <- density(bmds, na.rm = TRUE)
    X <- density.bmd$x; Y <- density.bmd$y
    dY <- diff(Y) / diff(X); dX <- rowMeans(embed(X, 2))
    dY.signs <- sign(dY); dY.signs.1 <- c(0, dY.signs[-length(dY.signs)])
    sign.changes <- dY.signs - dY.signs.1
    inds.maxes <- which(sign.changes == -2)
    inds.mins  <- which(sign.changes ==  2)

    bmd.temp <- bmds; bmds.tot <- length(bmd.temp)
    if (length(inds.mins) > 0 && length(inds.maxes) > 0) {
      mins <- dX[inds.mins]; maxes <- dX[inds.maxes]
      mins.maxes <- sort(c(mins, maxes))
      num.modes  <- length(mins.maxes) %/% 2
      mins.maxes <- mins.maxes[1:(2 * num.modes)]
      size.peaks <- per.peaks <- rep(NA_real_, num.modes)
      for (i in seq_len(num.modes)) {
        size.peaks[i] <- sum(bmd.temp < mins.maxes[2 * i])
        per.peaks[i]  <- size.peaks[i] / bmds.tot
        bmd.temp <- bmd.temp[!(bmd.temp < mins.maxes[2 * i])]
      }
      per.pass <- which(per.peaks > 0.05)
    } else if (length(inds.mins) == 0 && length(inds.maxes) > 0) {
      maxes <- dX[inds.maxes]
      per.pass <- 1
    } else {
      per.pass <- integer(0)
    }
    trans.pod["mode"] <- if (length(per.pass) > 0) unname(maxes[per.pass[1]]) else NA_real_
  }

  if (!missing(probe) && length(probe) > 0) {
    ok <- is.finite(bmds_raw) & bmds_raw > 0 & !is.na(probe)
    if (sum(ok) >= 1 && exists("LCRD")) {
      lcrd_raw <- tryCatch(LCRD(bmc = bmds_raw[ok], probe = probe[ok])$LCRD_Result$BMC, error = function(e) NA_real_)
      trans.pod["lcrd"] <- switch(
        scale,
        log10 = log10(lcrd_raw),
        log2  = log2(lcrd_raw),
        lcrd_raw
      )
    }
  }
  trans.pod
}

WriteAccuSummary <- function(files, outFile, scale = "raw") {
  res <- data.frame(
    file = character(0),
    n_genes = integer(0),
    bmd_min = character(0),
    bmd_median = character(0),
    bmd_max = character(0),
    tpod_feat20 = character(0),
    tpod_feat10th = character(0),
    tpod_mode = character(0),
    tpod_lcrd = character(0),
    stringsAsFactors = FALSE
  )

  for (i in seq_along(files)) {
    df <- AccuReadBmdFile(files[i])
    if (is.null(df)) {
      next
    }
    bmds_raw <- AccuExtractBmd(df)
    n_genes <- length(bmds_raw)
    probe <- if ("gene.id" %in% names(df)) {
      as.character(df$gene.id)
    } else if ("probe" %in% names(df)) {
      as.character(df$probe)
    } else if ("item" %in% names(df)) {
      as.character(df$item)
    } else {
      seq_along(bmds_raw)
    }
    tpods <- AccuComputeTPods(bmds_raw, probe, scale)
    res <- rbind(res, data.frame(
      file = basename(files[i]),
      n_genes = n_genes,
      bmd_min = ifelse(n_genes > 0, signif(min(bmds_raw, na.rm = TRUE), 4), NA),
      bmd_median = ifelse(n_genes > 0, signif(median(bmds_raw, na.rm = TRUE), 4), NA),
      bmd_max = ifelse(n_genes > 0, signif(max(bmds_raw, na.rm = TRUE), 4), NA),
      tpod_feat20 = ifelse(is.finite(tpods["feat.20"]), signif(tpods["feat.20"], 4), NA),
      tpod_feat10th = ifelse(is.finite(tpods["feat.10th"]), signif(tpods["feat.10th"], 4), NA),
      tpod_mode = ifelse(is.finite(tpods["mode"]), signif(tpods["mode"], 4), NA),
      tpod_lcrd = ifelse(is.finite(tpods["lcrd"]), signif(tpods["lcrd"], 4), NA),
      stringsAsFactors = FALSE
    ))
  }

  if (nrow(res) == 0) {
    return(0)
  }
  write.csv(res, outFile, row.names = FALSE)
  return(1)
}

PlotDRAccumulationAllMulti <- function(files, labels, tpodType, imgNm, dpi, format, units, scale) {
  require(ggplot2)
  require(Cairo)

  plot.df <- data.frame()
  tpod.df <- data.frame()
  max_genes <- 0

  for (i in seq_along(files)) {
    df <- AccuReadBmdFile(files[i])
    if (is.null(df)) {
      next
    }
    bmds_raw <- AccuExtractBmd(df)
    if (length(bmds_raw) == 0) {
      next
    }
    bmds_raw <- sort(bmds_raw)
    bmds <- switch(
      scale,
      log10 = log10(bmds_raw),
      log2  = log2(bmds_raw),
      bmds_raw
    )
    n_genes <- length(bmds)
    max_genes <- max(max_genes, n_genes)
    plot.df <- rbind(plot.df, data.frame(
      dataset = labels[i],
      bmd = bmds,
      cumulative = seq_len(n_genes),
      stringsAsFactors = FALSE
    ))

    probe <- if ("gene.id" %in% names(df)) {
      as.character(df$gene.id)
    } else if ("probe" %in% names(df)) {
      as.character(df$probe)
    } else if ("item" %in% names(df)) {
      as.character(df$item)
    } else {
      seq_along(bmds_raw)
    }
    tpods <- AccuComputeTPods(bmds_raw, probe, scale)
    if (!is.null(tpods[tpodType]) && is.finite(tpods[tpodType])) {
      tpod.df <- rbind(tpod.df, data.frame(
        dataset = labels[i],
        tpod = tpods[tpodType],
        stringsAsFactors = FALSE
      ))
    }
  }

  if (nrow(plot.df) == 0) {
    return(0)
  }

  if (scale == "log10") {
    xTitle <- paste0("log10(Feature-level BMD) (", units, ")")
  } else if (scale == "log2") {
    xTitle <- paste0("log2(Feature-level BMD) (", units, ")")
  } else {
    xTitle <- paste0("Feature-level BMD (", units, ")")
  }

  p <- ggplot(plot.df, aes(x = bmd, y = cumulative, color = dataset)) +
    geom_line(size = 1.1) +
    scale_y_continuous(
      limits = c(0, max_genes),
      expand = expansion(mult = c(0.01, 0.05))
    ) +
    scale_x_continuous(expand = expansion(mult = c(0.02, 0.02))) +
    theme_bw(base_size = 11 * 1.2) +
    xlab(xTitle) +
    ylab("Cumulative Number of Genes") +
    ggtitle(paste0("Gene Accumulation Plot - All Genes (", tpodType, ")")) +
    theme(
      axis.text.x = element_text(face = "bold"),
      axis.text.y = element_text(face = "bold"),
      plot.title = element_text(hjust = 0.5, face = "bold", size = rel(1.1)),
      plot.margin = margin(t = 10, r = 10, b = 10, l = 10)
    )

  if (nrow(tpod.df) > 0) {
    p <- p + geom_vline(data = tpod.df, aes(xintercept = tpod, color = dataset), linetype = "dashed", size = 0.9)
  }

  imgFile <- paste0(imgNm, "dpi", dpi, ".", format)
  Cairo(file = imgFile, width = 10, height = 6, unit = "in", dpi = dpi, type = format, bg = "white")
  print(p)
  dev.off()

  return(1)
}

PlotDRAccumulationTop100Multi <- function(files, labels, imgNm, dpi, format, units, scale) {
  require(ggplot2)
  require(Cairo)

  plot.df <- data.frame()
  max_genes <- 0

  for (i in seq_along(files)) {
    df <- AccuReadBmdFile(files[i])
    if (is.null(df)) {
      next
    }
    bmds_raw <- AccuExtractBmd(df)
    if (length(bmds_raw) == 0) {
      next
    }
    bmds_raw <- sort(bmds_raw)
    n_genes <- min(100, length(bmds_raw))
    bmds_raw <- bmds_raw[1:n_genes]
    bmds <- switch(
      scale,
      log10 = log10(bmds_raw),
      log2  = log2(bmds_raw),
      bmds_raw
    )
    max_genes <- max(max_genes, n_genes)
    plot.df <- rbind(plot.df, data.frame(
      dataset = labels[i],
      bmd = bmds,
      cumulative = seq_len(n_genes),
      stringsAsFactors = FALSE
    ))
  }

  if (nrow(plot.df) == 0) {
    return(0)
  }

  if (scale == "log10") {
    xTitle <- paste0("log10(Feature-level BMD) (", units, ")")
  } else if (scale == "log2") {
    xTitle <- paste0("log2(Feature-level BMD) (", units, ")")
  } else {
    xTitle <- paste0("Feature-level BMD (", units, ")")
  }

  p <- ggplot(plot.df, aes(x = bmd, y = cumulative, color = dataset)) +
    geom_line(size = 1.1) +
    scale_y_continuous(
      limits = c(0, max_genes),
      expand = expansion(mult = c(0.01, 0.05))
    ) +
    scale_x_continuous(expand = expansion(mult = c(0.05, 0.05))) +
    theme_bw(base_size = 11 * 1.2) +
    xlab(xTitle) +
    ylab("Cumulative Number of Genes") +
    ggtitle("Gene Accumulation Plot - Top 100 Genes") +
    theme(
      axis.text.x = element_text(face = "bold"),
      axis.text.y = element_text(face = "bold"),
      plot.title = element_text(hjust = 0.5, face = "bold", size = rel(1.1)),
      plot.margin = margin(t = 10, r = 10, b = 10, l = 10)
    )

  if (max_genes >= 20) {
    p <- p + geom_hline(yintercept = 20, linetype = "dashed", color = "#FF7F0E", size = 0.8)
  }

  imgFile <- paste0(imgNm, "dpi", dpi, ".", format)
  Cairo(file = imgFile, width = 10, height = 6, unit = "in", dpi = dpi, type = format, bg = "white")
  print(p)
  dev.off()

  return(1)
}

PlotDRHistogramOld <- function(imgNm, dpi, format, units, scale){
  paramSet <- readSet(paramSet, "paramSet");
  dataSet <- readDataset(paramSet$dataName);

  require(ggplot2)
  s.pods <- sensPOD(pod = c("feat.20", "feat.10th", "mode"), scale)

  bmd.hist <- dataSet$bmdcalc.obj$bmdcalc.res[dataSet$bmdcalc.obj$bmdcalc.res$all.pass,]

  if(scale == "log10"){
    dens <- density(log10(bmd.hist$bmd));
    xTitle <- paste0("log10(Gene-level BMD) (", units, ")")
  } else if(scale == "log2"){
    dens <- density(log2(bmd.hist$bmd));
    xTitle <- paste0("log2(Gene-level BMD) (", units, ")")
  } else {
    dens <- density(bmd.hist$bmd);
    xTitle <- paste0("Gene-level BMD (", units, ")")
  }

  dens <- data.frame(x = dens$x, y = dens$y)

  require(ggplot2)
  p <- ggplot(aes(x = x, y = y), data = dens) +
    geom_area() +
    geom_vline(aes(xintercept = s.pods[2], colour = "percentile10th"), size = 1) +
    geom_vline(aes(xintercept = s.pods[3], colour = "mode"), size = 1) +
    geom_vline(aes(xintercept = s.pods[1], colour = "gene20"), size = 1) +
    scale_color_manual(name = "tPOD",
                       values = c(gene20 = "#A7414A", percentile10th = "#6A8A82", mode = "#CC9B31"),
                       labels = c(paste0("20th gene: ", signif(s.pods[1],2)),
                                  paste0("Max 1st peak: ", signif(s.pods[3],2)),
                                  paste0("10th percentile: ", signif(s.pods[2],2)))) +
    theme_bw()
  p <- p + xlab(xTitle) + ylab("Density function") +
    theme(axis.text.x = element_text(face="bold"), legend.position = c(.95, .95),
          legend.justification = c("right", "top"),
          legend.box.just = "right")

  imgNm = paste(imgNm, "dpi", dpi, ".", format, sep="");
  Cairo (file=imgNm, width=8, height=6, unit="in",dpi=300, type=format, bg="white");
  print(p)
  dev.off();

  imgSet <- readSet(imgSet, "imgSet");
  imgSet$PlotDRHistogram <- imgNm;
    saveSet(imgSet, "imgSet");
}
